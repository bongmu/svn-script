#/bin/bash
yum -y install gcc*
yum -y install gd gd-devel
yum -y install expect
yum -y install mysql-devel telnet
sleep 10
rpm -ivh hero_libevent-2.0.21-1.el6.x86_64.rpm
rpm -ivh hero_libiconv-1.12-1.el6.x86_64.rpm
rpm -ivh hero_memcached-1.4.13-1.x86_64.rpm
rpm -ivh hero_mysql-5.1.63-1.el6.x86_64.rpm
rpm -ivh hero_nginx-1.2.0-1.x86_64.rpm
rpm -ivh hero_php-5.2.17-1.x86_64.rpm
rpm -ivh hero_pureftp-1.0.21-1.el6.x86_64.rpm
rpm -ivh hero_webphp-5.2.17-1.x86_64.rpm

ln -s /usr/lib64/libssl.so /usr/lib64/libssl.so.1.0.0
ln -s /usr/lib64/libcrypto.so /usr/lib64/libcrypto.so.1.0.0
sh /usr/local/webserver/php-5.2.17/php-fpm.sh
#mkdir -p /data/mysqllog/binlog/ 2>/dev/null
#chown -R mysql.root /data/mysqllog/binlog/
wget http://122.228.194.133:8080/mysqld -O /etc/init.d/mysqld
    chmod +x /etc/init.d/mysqld
#cp -rf my.cnf.master /etc/my.cnf

        chkconfig --add mysqld
        chkconfig mysqld on
        chkconfig --add memcached
        chkconfig --add nginx
        chkconfig nginx on
        chkconfig memcached on
        chkconfig --add php-fpm
        chkconfig php-fpm on
~                                        
